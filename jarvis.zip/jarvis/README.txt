JARVIS - HOW TO RUN (no experience needed)
==========================================

STEP 1. Install Python (one time)
  Go to python.org/downloads, install it.
  WINDOWS: tick "Add Python to PATH" on the first screen.

STEP 2. Get a free key (one time)
  Go to console.groq.com, sign up, click "API Keys", create one, copy it.

STEP 3. Unzip this folder, then open a terminal inside it
  Windows: open the folder, click the address bar, type  cmd  and press Enter.
  Mac: right-click the folder > "New Terminal at Folder".

STEP 4. Set up the key
  Windows:  copy .env.example .env
  Mac:      cp .env.example .env
  Open the new file named  .env  in Notepad and replace
  paste-your-free-key-here  with your key. Save.

STEP 5. Install (one time)
  Mac only, first:  brew install portaudio
  Then (both):      pip install -r requirements.txt

STEP 6. Check it works (no microphone needed)
  python test_jarvis.py
  It should print: ALL TESTS PASSED

STEP 7. Start Jarvis
  Voice:   python jarvis.py
  Typing:  python jarvis.py --text      (use this first if the microphone gives trouble)

HOW TO USE
  Say "Wake up Jarvis"  -> he wakes.   Say "Go to sleep Jarvis" -> he sleeps.
  Example: "Build me a landing page for a bakery with warm colours."
  Everything he creates is saved in the  workspace  folder.
  Before running any command he asks you to type y or n. Press y only if it looks fine.

VIDEO EDITING
  Install ffmpeg (ffmpeg.org). Put your video in the  workspace  folder, then say
  "Cut the first 10 seconds off intro.mp4" or "Join clip1.mp4 and clip2.mp4".
  iPad apps like Premiere and VN cannot be controlled from outside; edit on the laptop instead.

HE LEARNS
  When you correct him or tell him a preference, he saves it in  memory.md
  and uses it every time after that.

LIMITS (honest)
  - The free service has daily limits. If he stops answering, wait or change MODEL in .env.
  - Voice recognition uses Google's free service, so it needs internet.
  - He does not retrain himself; he improves by remembering what you tell him.
