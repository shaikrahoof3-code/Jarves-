"""Jarvis: wake word -> free LLM API -> tools -> voice. Run: python jarvis.py  (or --text to type)."""
import json, os, pathlib, re, subprocess, sys
from dotenv import load_dotenv
from openai import OpenAI

ROOT = pathlib.Path(__file__).parent
load_dotenv(ROOT / ".env")
WORK = ROOT / "workspace"  # Jarvis can only write files here
WORK.mkdir(exist_ok=True)
MEM = ROOT / "memory.md"  # what Jarvis has learned about you
MODEL = os.getenv("MODEL", "llama-3.3-70b-versatile")
WAKE = ("wake up jarvis", "wake up java")
SLEEP = ("go to sleep jarvis", "go to sleep java")

PERSONA = """You are Jarvis, a personal voice assistant with 15+ years of experience as a senior software engineer,
software architect and web designer. Replies are spoken aloud: keep them short and plain, no markdown.
When asked to build something, write the files with write_file (a website goes in an index.html you can open),
then say in one sentence what you made. Use run_command for things like git, python, npm and ffmpeg.
Design rules: pick one palette (60% neutral, 30% secondary, 10% accent), keep text contrast at least 4.5:1,
use at most two fonts, a consistent 8px spacing scale, generous whitespace, mobile first.
Video editing: use ffmpeg through run_command (cut, join, captions, resize, export).
When the user corrects you or states a preference, call remember. Never claim you did something you did not do."""


def _safe(p):
    f = (WORK / p).resolve()
    if f != WORK.resolve() and WORK.resolve() not in f.parents:
        raise ValueError("path is outside the workspace")
    return f


def write_file(path, content):
    f = _safe(path)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(content)
    return f"saved {path}"


def read_file(path):
    return _safe(path).read_text()[:8000]


def run_command(cmd):
    # shortcut: asks y/N in the terminal every time, upgrade to a safe-command allowlist if it gets annoying
    if input(f"\nJarvis wants to run: {cmd}   Allow? [y/N] ").strip().lower() != "y":
        return "user said no"
    r = subprocess.run(cmd, shell=True, cwd=WORK, capture_output=True, text=True, timeout=300)
    return (r.stdout + r.stderr)[-4000:] or "done"


def remember(note):
    with MEM.open("a") as f:
        f.write(f"- {note}\n")
    return "remembered"


FUNCS = {"write_file": write_file, "read_file": read_file, "run_command": run_command, "remember": remember}


def _tool(name, desc, **props):
    return {"type": "function", "function": {"name": name, "description": desc, "parameters": {
        "type": "object", "properties": {k: {"type": "string", "description": v} for k, v in props.items()},
        "required": list(props)}}}


TOOLS = [
    _tool("write_file", "Create or overwrite a file in the workspace", path="relative path", content="file text"),
    _tool("read_file", "Read a file from the workspace", path="relative path"),
    _tool("run_command", "Run a shell command in the workspace (user must approve)", cmd="the command"),
    _tool("remember", "Save a lasting note about the user's preferences or a correction", note="the note"),
]


def system():
    mem = MEM.read_text() if MEM.exists() else "nothing yet"
    return f"{PERSONA}\n\nWhat you know about the user:\n{mem}"


def ask(client, history, text):
    history.append({"role": "user", "content": text})
    for _ in range(6):
        msg = client.chat.completions.create(
            model=MODEL, messages=[{"role": "system", "content": system()}] + history, tools=TOOLS
        ).choices[0].message
        entry = {"role": "assistant", "content": msg.content or ""}
        if msg.tool_calls:
            entry["tool_calls"] = [{"id": c.id, "type": "function",
                                    "function": {"name": c.function.name, "arguments": c.function.arguments}}
                                   for c in msg.tool_calls]
        history.append(entry)
        if not msg.tool_calls:
            return msg.content or "Done."
        for c in msg.tool_calls:
            try:
                out = FUNCS[c.function.name](**json.loads(c.function.arguments))
            except Exception as e:
                out = f"error: {e}"
            history.append({"role": "tool", "tool_call_id": c.id, "content": str(out)})
    return "I got stuck on that one, please try again."


def clean(s):
    return re.sub(r"[^a-z ]", "", s.lower()).strip()


def step(client, state, heard):
    """One turn of the wake/sleep state machine. Returns the reply to speak, or None."""
    h = clean(heard)
    if not state["awake"]:
        if any(w in h for w in WAKE):
            state["awake"] = True
            return "I'm awake. What do you need?"
        return None
    if any(w in h for w in SLEEP):
        state["awake"], state["history"] = False, []
        return "Going to sleep."
    return ask(client, state["history"], heard) if h else None


def main():
    text_mode = "--text" in sys.argv
    if not os.getenv("API_KEY"):
        sys.exit("Put your key in the .env file first (see README.txt).")
    client = OpenAI(api_key=os.getenv("API_KEY"), base_url=os.getenv("BASE_URL", "https://api.groq.com/openai/v1"))
    if text_mode:
        listen, speak = (lambda: input("You: ")), (lambda t: print("Jarvis:", t))
    else:
        import pyttsx3, speech_recognition as sr
        engine, rec = pyttsx3.init(), sr.Recognizer()

        def speak(t):
            print("Jarvis:", t)
            engine.say(t)
            engine.runAndWait()

        def listen():
            with sr.Microphone() as mic:
                rec.adjust_for_ambient_noise(mic, 0.3)
                audio = rec.listen(mic, phrase_time_limit=15)
            try:
                return rec.recognize_google(audio)  # free, needs internet
            except sr.UnknownValueError:
                return ""
    state = {"awake": False, "history": []}
    print('Say "Wake up Jarvis" to start. Ctrl+C to quit.')
    while True:
        reply = step(client, state, listen())
        if reply:
            speak(reply)


if __name__ == "__main__":
    main()
