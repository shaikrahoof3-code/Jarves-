"""Offline self-check: python test_jarvis.py  (no API key or microphone needed)."""
import json, os
from types import SimpleNamespace as NS

os.environ["API_KEY"] = "x"
try:
    import openai, dotenv  # noqa: F401
except ImportError:  # the test never calls the real API, so stand-ins are enough
    import sys, types
    sys.modules["openai"] = types.SimpleNamespace(OpenAI=object)
    sys.modules["dotenv"] = types.SimpleNamespace(load_dotenv=lambda *a, **k: None)
import jarvis


def call(name, **args):
    return NS(id="1", function=NS(name=name, arguments=json.dumps(args)))


class FakeClient:
    """First reply asks to write a file, second reply is the spoken answer."""
    def __init__(self):
        self.n = 0
        self.chat = NS(completions=NS(create=self.create))

    def create(self, **kw):
        self.n += 1
        m = NS(content=None, tool_calls=[call("write_file", path="t/hi.txt", content="hello")]) if self.n == 1 \
            else NS(content="Saved it.", tool_calls=None)
        return NS(choices=[NS(message=m)])


# tools stay inside the workspace
assert jarvis.write_file("t/a.txt", "x") == "saved t/a.txt"
try:
    jarvis.write_file("../evil.txt", "x")
    raise SystemExit("FAIL: escaped workspace")
except ValueError:
    pass

# wake word: ignored while asleep, works after, sleeps again
c, s = FakeClient(), {"awake": False, "history": []}
assert jarvis.step(c, s, "make me a website") is None and c.n == 0
assert "awake" in jarvis.step(c, s, "Wake up, Jarvis!")
assert jarvis.step(c, s, "make a hello file") == "Saved it."
assert (jarvis.WORK / "t/hi.txt").read_text() == "hello"
assert jarvis.step(c, s, "Go to sleep Jarvis") == "Going to sleep." and not s["awake"]

# memory
jarvis.MEM = jarvis.WORK / "mem_test.md"
jarvis.remember("likes dark themes")
assert "dark themes" in jarvis.system()
print("ALL TESTS PASSED")
